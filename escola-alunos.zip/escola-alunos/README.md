# Cadastro de alunos — Django + SQLite

Projeto do tutorial enviado: cadastro, listagem, edição e exclusão de alunos.

## Requisitos
- Windows 10/11
- Python 3.13 (ou versão compatível com Django 6.1)
- VS Code

## Executar no Windows (PowerShell)

Abra esta pasta no VS Code e, no terminal integrado, execute:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python manage.py makemigrations alunos
python manage.py migrate
python manage.py runserver
```

Acesse http://127.0.0.1:8000/

Se o PowerShell bloquear a ativação do ambiente virtual, execute uma vez:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

Depois feche e reabra o terminal e tente ativar novamente.

## Funcionalidades
- Cadastrar aluno (nome, e-mail, data de nascimento e turma)
- Listar alunos em ordem alfabética
- Editar cadastro
- Excluir com tela de confirmação
- Validação de e-mail único

O banco SQLite é criado automaticamente no arquivo `db.sqlite3` após `migrate`.
O Bootstrap é carregado por CDN, portanto a primeira visualização estilizada exige internet.

## Observação
Este pacote está preparado para execução local conforme o tutorial. Antes de publicar em produção, configure uma `SECRET_KEY` segura, `DEBUG`, `ALLOWED_HOSTS`, CSRF e um banco persistente adequado ao ambiente de hospedagem.
